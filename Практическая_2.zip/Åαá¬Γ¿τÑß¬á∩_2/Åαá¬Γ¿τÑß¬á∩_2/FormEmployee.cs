﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Практическая_2
{
    public partial class FormEmployee : Form
    {
        public FormEmployee()
        {
            InitializeComponent();
        }

        private void отчётToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }


        private void отменитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Undo();

        }

        void Undo()
        {
            DisplayMethod(true);
            MessageBox.Show("метод Undo");

        }

        private void редактироватьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Edit();
        }

        void Edit()
        {
            DisplayMethod(false);
            MessageBox.Show("метод Edit");
        }

        private void сохранитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Save();
        }

        void Save()
        {
            DisplayMethod(true);
            MessageBox.Show("метод Save");
        }

        private void удалитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            Remove();
        }

        void Remove()
        {
            DisplayMethod(true);
            DialogResult result = MessageBox.Show(" Удалить данные \n по сотруднику ?", "Предупреждение", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
            switch (result)
            {
                case DialogResult.Yes:
                    {
                        //выполнить действия по удалению данных по сотруднику 
                        MessageBox.Show("Удаление данных");
                        break;
                    }
                case DialogResult.No:
                    {
                        //отмена удаления данных по сотруднику 
                        MessageBox.Show("Отмена удаления данных");
                        break;
                    }
            }
        }

        private void создатьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            New();
        }

        void New()
        {
            DisplayMethod(false);
            MessageBox.Show("метод New");
        }

        private void FormEmployee_Load(object sender, EventArgs e)
        {
            DisplayMethod(true);
            DisplayReadOnly();
            
        }

        private void toolStripButtonUndo_Click(object sender, EventArgs e)
        {

            Undo();
        }

        private void toolStripButtonNew_Click(object sender, EventArgs e)
        {
            New();
        }

        private void toolStripButtonEdit_Click(object sender, EventArgs e)
        {
            Edit();
        }

        private void toolStripButtonSave_Click(object sender, EventArgs e)
        {
            Save();
        }

        private void toolStripButtonRemove_Click(object sender, EventArgs e)
        {
            Remove();
        }

        private void отменитьToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Undo();
        }

        private void создатьToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            New();
        }

        private void редактироватьToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Edit();
        }

        private void сохранитьToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Save();
        }

        private void удалитьToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Remove();
        }

        private void действиеToolStripMenuItem_MouseEnter(object sender, EventArgs e)
        {
            toolStripStatusLabelEmployee.Text = "Выбор действий по сотрудникам";
        }

        private void действиеToolStripMenuItem_MouseLeave(object sender, EventArgs e)
        {
            toolStripStatusLabelEmployee.Text = "";
        }

        private void отменитьToolStripMenuItem_MouseEnter(object sender, EventArgs e)
        {
            toolStripStatusLabelEmployee.Text = "отменить редактирование данных по сотруднику";
        }

        private void отменитьToolStripMenuItem_MouseLeave(object sender, EventArgs e)
        {
            toolStripStatusLabelEmployee.Text = "";
        }

        private void создатьToolStripMenuItem_MouseEnter(object sender, EventArgs e)
        {
            toolStripStatusLabelEmployee.Text = "Создать новые данные по сотруднику";
        }

        private void создатьToolStripMenuItem_MouseLeave(object sender, EventArgs e)
        {
            toolStripStatusLabelEmployee.Text = "";
        }

        private void редактироватьToolStripMenuItem_MouseEnter(object sender, EventArgs e)
        {
            toolStripStatusLabelEmployee.Text = "Редактировать данные по сотруднику";
        }

        private void редактироватьToolStripMenuItem_MouseLeave(object sender, EventArgs e)
        {
            toolStripStatusLabelEmployee.Text = "";
        }

        private void сохранитьToolStripMenuItem_MouseEnter(object sender, EventArgs e)
        {
            toolStripStatusLabelEmployee.Text = "Сохранить изменения в данных по сотруднику";
        }

        private void сохранитьToolStripMenuItem_MouseLeave(object sender, EventArgs e)
        {
            toolStripStatusLabelEmployee.Text = "";
        }

        private void удалитьToolStripMenuItem_MouseEnter(object sender, EventArgs e)
        {
            toolStripStatusLabelEmployee.Text = "Удалить данные по сотруднику";
        }

        private void удалитьToolStripMenuItem_MouseLeave(object sender, EventArgs e)
        {
            toolStripStatusLabelEmployee.Text = "";
        }

        private void отчётToolStripMenuItem_MouseEnter(object sender, EventArgs e)
        {
            toolStripStatusLabelEmployee.Text = "Информация о отчётах по сотрудникам";
        }

        private void отчётToolStripMenuItem_MouseLeave(object sender, EventArgs e)
        {
            toolStripStatusLabelEmployee.Text = "";
        }

        private void поСотрудникуToolStripMenuItem_MouseEnter(object sender, EventArgs e)
        {
            toolStripStatusLabelEmployee.Text = "Просмотреть информацию по определенному сотруднику";
        }

        private void поСотрудникуToolStripMenuItem_MouseLeave(object sender, EventArgs e)
        {
            toolStripStatusLabelEmployee.Text = "";
        }

        private void поВсемСотрудникамToolStripMenuItem_MouseEnter(object sender, EventArgs e)
        {
            toolStripStatusLabelEmployee.Text = "Просмотреть информацию по всем сотрудникам";
        }

        private void поВсемСотрудникамToolStripMenuItem_MouseLeave(object sender, EventArgs e)
        {
            toolStripStatusLabelEmployee.Text = "";
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
         // режим просмотра формы:
        public void DisplayReadOnly()
        {
            this.textBoxSurname.ReadOnly = true;
            this.textBoxName.ReadOnly = true;
            this.textBoxPatronymic.ReadOnly = true;
            this.textBoxNetName.ReadOnly = true;
            this.comboBoxJobRole.Enabled = false;
            this.comboBoxStatus.Enabled = false;
            this.comboBoxAccess.Enabled = false;
        }
        // Задание режима редактирования:
        public void DisplayEdit()
        {
            this.textBoxSurname.ReadOnly = false;
            this.textBoxName.ReadOnly = false;
            this.textBoxPatronymic.ReadOnly = false;
            this.textBoxNetName.ReadOnly = false;
            this.comboBoxJobRole.Enabled = true;
            this.comboBoxStatus.Enabled = true;
            this.comboBoxAccess.Enabled = true;
        } 
        public void DisplayReadOnly(bool ReadOnly)
        {
            this.textBoxSurname.ReadOnly = ReadOnly;
            this.textBoxName.ReadOnly = ReadOnly;
            this.textBoxPatronymic.ReadOnly = ReadOnly;
            this.textBoxNetName.ReadOnly = ReadOnly;
            this.comboBoxJobRole.Enabled = !ReadOnly;
            this.comboBoxStatus.Enabled = !ReadOnly;
            this.comboBoxAccess.Enabled = !ReadOnly;
        }



        public void MenuItemEnabled(bool itemEnabled)
        {
            this.отменитьToolStripMenuItem.Enabled = !itemEnabled;
            this.создатьToolStripMenuItem.Enabled = itemEnabled;
            this.редактироватьToolStripMenuItem.Enabled = itemEnabled;
            this.сохранитьToolStripMenuItem.Enabled = !itemEnabled;
            this.удалитьToolStripMenuItem.Enabled = itemEnabled;
        }
        public void MenuItemContextEnabled(bool itemEnabled)
        {
            this.отменитьToolStripMenuItem1.Enabled = !itemEnabled;
            this.создатьToolStripMenuItem1.Enabled = itemEnabled;
            this.редактироватьToolStripMenuItem1.Enabled = itemEnabled;
            this.сохранитьToolStripMenuItem1.Enabled = !itemEnabled;
            this.удалитьToolStripMenuItem1.Enabled = itemEnabled;
        }
        public void StripButtonEnabled(bool itemEnabled)
        {
            this.toolStripButtonUndo.Enabled = !itemEnabled;
            this.toolStripButtonNew.Enabled = itemEnabled;
            this.toolStripButtonEdit.Enabled = itemEnabled;
            this.toolStripButtonSave.Enabled = !itemEnabled;
            this.toolStripButtonRemove.Enabled = itemEnabled;

        }
        // Глав. меню формы
        private void MainMenu(bool state)
        {
            отменитьToolStripMenuItem.Enabled = !state;
            создатьToolStripMenuItem.Enabled = state;
            сохранитьToolStripMenuItem.Enabled = !state;
            редактироватьToolStripMenuItem.Enabled = state;
            удалитьToolStripMenuItem.Enabled = state;
        }

        // Контекстное меню
        private void MenuContex(bool state)
        {
            отменитьToolStripMenuItem1.Enabled = !state;
            создатьToolStripMenuItem1.Enabled = state;
            сохранитьToolStripMenuItem1.Enabled = !state;
            редактироватьToolStripMenuItem1.Enabled = state;
            удалитьToolStripMenuItem1.Enabled = state;
        }

        // Панель инструментов
        private void MenuTool(bool state)
        {
            toolStripButtonUndo.Enabled = !state;
            toolStripButtonNew.Enabled = state;
            toolStripButtonEdit.Enabled = state;
            toolStripButtonSave.Enabled = !state;
            toolStripButtonRemove.Enabled = state;
        }

        private void Elements(bool state)
        {
            this.textBoxSurname.ReadOnly = state;
            this.textBoxName.ReadOnly = state;
            this.textBoxPatronymic.ReadOnly = state;
            this.textBoxNetName.ReadOnly = state;
            this.comboBoxJobRole.Enabled = !state;
            this.comboBoxStatus.Enabled = !state;
            this.comboBoxAccess.Enabled = !state;
        }

        private void DisplayMethod(bool mode)
        {
            
            MainMenu(mode);
            MenuContex(mode);
            Elements(mode);
            MenuTool(mode);
            /* true  - Просмотр
             false - Изменение */
        }

        private void DisplayForm(bool mode)
        {
                            
                DisplayReadOnly(mode);
                MenuItemEnabled(mode);
                MenuItemContextEnabled(mode);
                StripButtonEnabled(mode);
            
        }
    }
}
